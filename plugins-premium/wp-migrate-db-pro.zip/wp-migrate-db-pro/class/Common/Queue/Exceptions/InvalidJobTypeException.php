<?php

namespace DeliciousBrains\WPMDB\Common\Queue\Exceptions;

use Exception;

class InvalidJobTypeException extends Exception {
    //
}
