<?php

namespace DeliciousBrains\WPMDBMF;

class MediaFilesLocal {
    //Silence is golden.
}
