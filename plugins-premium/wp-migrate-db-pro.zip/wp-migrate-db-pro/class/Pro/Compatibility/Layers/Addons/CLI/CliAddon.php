<?php

namespace DeliciousBrains\WPMDBCli;

class CliAddon {
    //Silence is golden.
}
