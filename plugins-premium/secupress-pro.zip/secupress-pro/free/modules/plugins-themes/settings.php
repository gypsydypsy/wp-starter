<?php
defined( 'ABSPATH' ) or die( 'Something went wrong.' );

$this->load_plugin_settings( 'uploads' );
$this->load_plugin_settings( 'plugins' );
$this->load_plugin_settings( 'themes' );
