<?php
defined( 'ABSPATH' ) or die( 'Something went wrong.' );

$this->load_plugin_settings( 'file-scanner' );
$this->load_plugin_settings( 'bad-file-extensions' );
