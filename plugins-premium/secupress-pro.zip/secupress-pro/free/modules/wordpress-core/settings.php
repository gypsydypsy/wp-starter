<?php
defined( 'ABSPATH' ) or die( 'Something went wrong.' );

$this->load_plugin_settings( 'auto-update' );
$this->load_plugin_settings( 'database' );
$this->load_plugin_settings( 'wp-config' );
