<?php
defined( 'ABSPATH' ) or die( 'Something went wrong.' );

$this->load_plugin_settings( 'banned-ips' );
$this->load_plugin_settings( 'logs' );
