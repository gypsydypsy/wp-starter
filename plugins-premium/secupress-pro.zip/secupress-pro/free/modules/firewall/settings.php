<?php
defined( 'ABSPATH' ) or die( 'Something went wrong.' );

$this->load_plugin_settings( 'bbq-headers' );
$this->load_plugin_settings( 'bbq-url-content' );
$this->load_plugin_settings( 'geoip-system' );
